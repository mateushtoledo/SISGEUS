package Controladores;

import java.util.*;
import java.io.*;
import Entidades.*;
import Limites.LimiteCadastroFuncionario;

public class ControleFuncionario {
    private ArrayList<Funcionario> objFuncionarios;

    public ControleFuncionario() {
        objFuncionarios = new ArrayList<>();
    }
    
    public void cadastrarFuncionario(String pNome, String pNumFuncional, String pFuncao)
    {
        objFuncionarios.add(new Funcionario(pNome, pNumFuncional, pFuncao));
    }
    
    public void cadastrarMedico(String pNome, String pNumFuncional, String pFuncao,String pEspecializacao)
    {
        objFuncionarios.add(new Medico(pNome, pNumFuncional, pFuncao, pEspecializacao));
    }
    
    //Metodo que marca uma consulta na agenda do medico (se o horario estiver disponivel)
    public Medico marcarConsulta(String pEspecialidade, String pNumBeneficiarioPaciente, String pMotivo, String pNumFuncionalFuncionario, Date pData,Date pRegistro)
    {
        for(Funcionario func : objFuncionarios)
        {
            if(func instanceof Medico)
            {
                Medico doctor = (Medico)func;
                if(doctor.getEspecializacao().equals(pEspecialidade))
                {
                    boolean resultado = doctor.marcarConsulta(pEspecialidade, pNumBeneficiarioPaciente, pMotivo, pNumFuncionalFuncionario, pData, pRegistro);
                    
                    if(resultado)
                        return doctor;
                }
            }
        }
        
        return null;
    }
    
    //Metodo que remove determinada consulta da agenda do medico
    public void anularConsultaDaAgendaDoMedico(Consulta pConsulta)
    {
        for(Funcionario func : objFuncionarios)
        {
            if(func instanceof Medico)
            {
                Medico doctor = (Medico)func;
                
                boolean resultado = doctor.removerConsulta(pConsulta);
            }
        }
    }
    
    //Metodo que exibe uma interface para realizar o cadastro de funcionario
    public void interfaceCadastroFuncionario()
    {
        new LimiteCadastroFuncionario(this);
    }
    
    //Metodo que retorna todos os funcionarios atendentes do sistema
    public ArrayList<Funcionario> obterAtendentes()
    {
        ArrayList<Funcionario> objAtendentes = new ArrayList<>();
        
        for(Funcionario func : objFuncionarios)
        {
            if(func.getFuncao().equals(Funcionario.ATENDENTE))
                objAtendentes.add(func);
        }
        
        return objAtendentes;
    }
    
    //Metodo que retorna todos os funcionarios medicos dom sistema
    public ArrayList<Medico> obterMedicos()
    {
        ArrayList<Medico> objMedicos = new ArrayList<>();
        
        for(Funcionario func : objFuncionarios)
        {
            if(func instanceof Medico)
                objMedicos.add((Medico)func);
        }
        
        return objMedicos;
    }
    
    //Metodo que verifica se os dados informados sao de determinado atendente
    //Retorna verdadeiro se algum atendente for encontrado.
    public boolean loginAtendente(String pNome,String pNumFuncional)
    {
        for(Funcionario func : objFuncionarios)
        {
            if(func.getFuncao().equals(Funcionario.ATENDENTE))
            {
                if(func.getNome().equals(pNome) && func.getNumFuncional().equals(pNumFuncional))
                    return true;
            }
        }
        return false;
    }
    
    //Metodo que verifica se os dados informados sao de algum medico
    //Retorna verdadeiro se algum medico for encontrado.
    public boolean loginMedico(String pNome,String pNumFuncional)
    {
        for(Funcionario func : objFuncionarios)
        {
            if(func.getFuncao().equals(Funcionario.MEDICO))
            {
                if(func.getNome().equals(pNome) && func.getNumFuncional().equals(pNumFuncional))
                    return true;
            }
        }
        return false;
    }
    
    //Metodo que verifica se os dados informados sao do responsavel por pessoal da unidade
    //Retorna verdadeiro se forem.
    public boolean loginResponsavelPorPessoal(String pNome,String pNumFuncional)
    {
        if(pNome.equals("Jean Carlos de Oliveira") && pNumFuncional.equals("35138"))
            return true;
        else
            return false;
    }
    
    //Metodo que salva a lista de funcionarios do sistema em arquivo de texto
    public void salvarFuncionarios() throws Exception
    {
        FileOutputStream fileOs = new FileOutputStream("funcionarios.dat");
        ObjectOutputStream objOs = new ObjectOutputStream(fileOs);
        objOs.writeObject(objFuncionarios);
        objOs.flush();
        objOs.close();
    }
    
    //Metodo que recupera a lista de funcionarios do sistema do arquivo de texto
    public void recuperarFuncionarios() throws Exception
    {
        File arquivo = new File("funcionarios.dat");
        
        if(arquivo.exists())
        {
            FileInputStream fileIs = new FileInputStream(arquivo);
            ObjectInputStream objIs = new ObjectInputStream(fileIs);
            objFuncionarios = (ArrayList<Funcionario>)objIs.readObject();
            objIs.close();
        }
    }
}
