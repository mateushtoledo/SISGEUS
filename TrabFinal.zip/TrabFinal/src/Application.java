
import Controladores.ControlePrincipal;

public class Application {
    public static void main(String args[])
    {
        ControlePrincipal control = new ControlePrincipal();
    }
}
